package EMS;

import java.sql.*;

/**
 * Author: HP
 */
public class ViewDetails2 extends javax.swing.JFrame {
 
    /**
     * Creates new form ViewDetails2
     */
    public ViewDetails2() {
        initComponents();
        // Call method to display details of the current user
        viewCurrentUserDetails();
    }

   
    private void viewCurrentUserDetails() {
        try {
            clearFields();
            ConnectionClass obj = new ConnectionClass();
            int userId = getCurrentUserId(); // Assuming you have a method to get the current user's ID
            String selectQuery = "SELECT * FROM User WHERE Reg_ID = ?";
            PreparedStatement pst = obj.con.prepareStatement(selectQuery);
            pst.setInt(1, userId);
            ResultSet rs = pst.executeQuery();
            // Display details in the text areas
            if (rs.next()) {
                tfreg_id.setText(rs.getString("Reg_ID"));
            tfname.setText(rs.getString("Name"));
            tfmobile_no.setText(rs.getString("Phone_No"));
            tfcity.setText(rs.getString("City"));
            tfaddress.setText(rs.getString("Address"));
            tfemail.setText(rs.getString("Email"));
            }
           
            rs.close();
            pst.close();
        } catch (Exception e) {
            e.printStackTrace();
        }    
    }

   
    private void clearFields() {
        tfreg_id.setText("");
        tfname.setText("");
        tfmobile_no.setText("");
        tfcity.setText("");
        tfaddress.setText("");
        tfemail.setText("");
    }

    
    private int getCurrentUserId() {
       
        return 1;
    }
                  
    private javax.swing.JButton Back;
    private javax.swing.JPasswordField Tfpassword;
    private javax.swing.JLabel email;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel mobile_no;
    private javax.swing.JLabel name;
    private javax.swing.JLabel pass;
    private javax.swing.JTextField tfaddress;
    private javax.swing.JTextField tfcity;
    private javax.swing.JTextField tfemail;
    private javax.swing.JTextField tfmobile_no;
    private javax.swing.JTextField tfname;
    private javax.swing.JTextField tfreg_id;
    private javax.swing.JLabel username;
    private javax.swing.JLabel username1;
    
   
    private void initComponents() {

        Tfpassword = new javax.swing.JPasswordField();
        jLabel1 = new javax.swing.JLabel();
        name = new javax.swing.JLabel();
        email = new javax.swing.JLabel();
        mobile_no = new javax.swing.JLabel();
        username = new javax.swing.JLabel();
        pass = new javax.swing.JLabel();
        tfreg_id = new javax.swing.JTextField();
        tfname = new javax.swing.JTextField();
        tfmobile_no = new javax.swing.JTextField();
        tfaddress = new javax.swing.JTextField();
        Back = new javax.swing.JButton();
        tfemail = new javax.swing.JTextField();
        username1 = new javax.swing.JLabel();
        tfcity = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("View Details");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 30, 210, -1));

        name.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        name.setForeground(new java.awt.Color(255, 255, 255));
        name.setText("Reg ID");
        getContentPane().add(name, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 110, -1, -1));

        email.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        email.setForeground(new java.awt.Color(255, 255, 255));
        email.setText("Name");
        getContentPane().add(email, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 150, -1, -1));

        mobile_no.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        mobile_no.setForeground(new java.awt.Color(255, 255, 255));
        mobile_no.setText("Mobile No.");
        getContentPane().add(mobile_no, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 190, 90, -1));

        username.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        username.setForeground(new java.awt.Color(255, 255, 255));
        username.setText("City");
        getContentPane().add(username, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 270, -1, -1));

        pass.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        pass.setForeground(new java.awt.Color(255, 255, 255));
        pass.setText("Email");
        getContentPane().add(pass, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 310, -1, -1));
        getContentPane().add(tfreg_id, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 110, 167, -1));
        getContentPane().add(tfname, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 150, 167, -1));
        getContentPane().add(tfmobile_no, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 190, 167, -1));
        getContentPane().add(tfaddress, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 230, 167, -1));

        Back.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        Back.setText("Back");
        Back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackActionPerformed(evt);
            }
        });
        getContentPane().add(Back, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 360, -1, -1));
        getContentPane().add(tfemail, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 310, 167, -1));

        username1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        username1.setForeground(new java.awt.Color(255, 255, 255));
        username1.setText("Address");
        getContentPane().add(username1, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 230, -1, -1));
        getContentPane().add(tfcity, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 270, 170, -1));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Bkg1.jpg"))); // NOI18N
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 560, 430));

        pack();
    }                     

    // Action performed when back button is clicked
    private void BackActionPerformed(java.awt.event.ActionEvent evt) {                                     
        // TODO add your handling code here:
        new UserPage().setVisible(true);
        this.setVisible(false);
    }                                    

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ViewDetails2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new ViewDetails2().setVisible(true);
        });
    }
}
