package EMS;
import java.sql.*;

public class ConnectionClass {

    static Connection connectDB() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    Connection con;
    Statement stm;
    
    ConnectionClass()
    {
        try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/EMS","root","12345");
            stm=con.createStatement();
        }
        catch(ClassNotFoundException | SQLException e)
        {
           e.printStackTrace();
        }
    }
    public static void main(String[] args)
    {
        new ConnectionClass();
    }
}
