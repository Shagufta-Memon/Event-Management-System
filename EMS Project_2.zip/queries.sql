CREATE TABLE VENUE (
    Venue_ID VARCHAR(30) PRIMARY KEY,
    Venue_Name VARCHAR(30) NOT NULL,
    Event_Type VARCHAR(30),
    City VARCHAR(30) NOT NULL,
    Capacity INT NOT NULL,
    Budget VARCHAR(30) NOT NULL
);


CREATE TABLE EVENT_BOOKINGS (
    Booking_ID varchar(36),
    Reg_ID Int auto_increment,
    Venue_ID varchar(30) not null,
    Venue_Name varchar(30) not null,
    Event_Type varchar(30) not null,
    Capacity int not null,
    Date varchar(30) not null,
    Shift varchar(30) not null,
    Time Varchar(30) not null,
    Status varchar(30) not null,
    PRIMARY KEY (Booking_ID),
    FOREIGN KEY (Reg_ID) REFERENCES registration(Reg_ID),
    FOREIGN KEY (Venue_ID) REFERENCES venue(Venue_ID)
);


CREATE TABLE USER(Reg_ID INT,
 Name varchar(30) not null,
 Phone_No varchar(20) not null,
 City varchar(30) not null,
 Address varchar(30) not null,
 Email varchar(45) not null,
 foreign key (Reg_ID) references Registration(Reg_ID)
 );

 CREATE TABLE Registration(
Reg_ID INT auto_increment,
Username Varchar(30),
Password Varchar(30) not null,
Email varchar(45) not null,
Primary key (Reg_ID));
